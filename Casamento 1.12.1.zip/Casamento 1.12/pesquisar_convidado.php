
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- Metas para telefone -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>Casamento</title>
    <!-- Metas para o site-->
    <meta name="keywords" content="">
    <meta name="description" content="Este é um site sobre convite digital">
    <meta name="author" content="Luís Luamba">
    <!-- Links  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <!-- Para funcionar em outros navegadores -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->


</head>
<body>
<div>
<div class="col-6   card-administrador-1">
                <!-- Primeiro Card -->
               <h5 class="text-center p-2 text-info bg-dark">PESQUISE AQUI</h5>
               <div class="container" >
                <div class="table-responsive">
<!-- campo de pesdquisa -->

<table class="table table-striped table-hover table-bordered table-dark">
<tr class="bg-dark text-white text-center"> 

                    <th> ID</th>
                    <th> NOME</th>                
                    <th> MESA</th>
                    <th> CELULAR</th>                 
                    <th> ENTRAR</th>
                    <th> FALTOSO</th>
                    
                    </tr >  
</table>
<!-- Formuláriopara o campo de Pesquisa -->
<form action="" method="post"> 
     <input type="text"  name="search" id="search">
     <!-- Formulário junto com a tabela -->
</form>
<table class="table table-striped table-hover table-bordered table-dark  " id="myTable">

                    <tr class="bg-dark text-white text-center"> 

                    <!-- <th> ID</th>
                    <th> NOME</th>                
                    <th> MESA</th>
                    <th> CELULAR</th>                 
                    <th> ENTRAR</th>
                    <th> FALTOSO</th>
                     -->
                    </tr >   
                    <?php
            include "conexao.php";
                $query = mysqli_query($conn, "SELECT * FROM login  LIMIT 5");
                // Exibindo os resulados  
  
                while($res= mysqli_fetch_array($query))
                {
                ?>  
                    
                    <tr class="text-center">

                    <td> <?php  echo $res['id']; ?> </td>
                    <td> <?php  echo $res['usermane']; ?> </td>                                  
                    <td> <?php  echo $res['mesa']; ?></td>
                    <td> <?php  echo $res['telefone']; ?></td>
                   
                    <!-- Botão faltoso  -->
                    <td> 
                    <button class="btn-danger btn "> 
                    <a href="delete.php?id=<?php echo $res['id'];?>" class="text-white" > FALTOSO </a>
                    </button> 
                    </td>
                        <!-- Botão entar  -->
                    <td> 
                    <button class="btn-info btn "> 
                    <a href="delete.php?id=<?php echo $res['id'];?>" class="text-white" > ENTRAR</a>
                    </button> 
                    </td>

                    </tr >

                    <?php
                    }

                    ?>
</table>

        </div>
         </div>
         </div>
</div>
</div>



<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

<!-- Barra De Pesquisa -->
<script type="text/javascript">
 $(document).ready(function(){
  $('#search').keyup(function(){
    //   ver search = $(this).val();
    //   $.a
     search_table($(this).val());
  });

  function search_table(value){
    $('#myTable tr').each(function(){
        var found ='false';
        $(this).each(function(){
       if( $(this).text().toLowerCase().indexOf(value.toLowerCase())>=0)
        {
        found = 'true';
        }
        });    

        if (found=='true') 
        {
            $(this).show();
        }
        else
        {
            $(this).hide();

        }
          
    });
    
  }
     
 });
</script>


</body>
</html>
