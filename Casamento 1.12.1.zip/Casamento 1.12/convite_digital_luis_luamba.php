<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<?php
include "conexao.php";


ob_start();
require_once ("fpdf/fpdf.php");

// CRIANDO UM OBEJCTO
$pdf = new FPDF('P','mm','A4');
$pdf ->AliasNbPages('{pages}');
// ADICIONANDO A PAGINA 
$pdf ->AddPage();
// ADICIONANDO A FONT
// $pdf ->SetFont('Arial','B',18);
// ADICIONANDO  ASD LINHASS 
// $pdf->cell (80,30,'');
// $pdf->cell (20,10,'SEU CONVITE');

// ADICIONANDO A IMAGEM 
// $pdf->Image('assets/convite/ConviteCasamento.jpg',10,20,189);
// $pdf->cell (2,100,'SEU CONVITE');


$pdf ->SetFont('Arial','B',12);
$pdf ->SetFillcolor(18,180,252); 
$pdf ->SetDrawColor(60,60,100);
 
$pdf->cell (20,5,'CODIGO ',1,0,'',true);
$pdf->cell (60,5,'NOME E APELIDO',1,0,'',true);
$pdf->cell (30,5,'TELEFONE',1,0,'',true);
$pdf->cell (30,5,'MESA',1,0,'',true);
$pdf->cell (43,5,'DATA DO CONVITE',1,1,'',true);


$id = $_GET['id'];  
$query = mysqli_query($conn, "SELECT id, usermane, telefone,mesa,data_cadastro FROM login WHERE id=$id");
while($data = mysqli_fetch_array($query))
{

    $pdf ->SetFillcolor(18,180,252);
    $pdf ->SetDrawColor(50,50,100); 
$pdf->Cell (20,5,$data['id']      ,1,0);
$pdf->Cell (60,5,$data['usermane'],1,0);
$pdf->Cell (30,5,$data['telefone'],1,0);
$pdf->Cell (30,5,$data['mesa'],1,0);  
$pdf->Cell (43,5,$data['data_cadastro'],1,1);  

}
$pdf->Image('assets/convite/ConviteCasamento.jpg',10,50,189);






$pdf->output();
ob_end_flush();
?>

</body>
</html>