<?php

$host ="localhost";
$usuario = "root";
$senha="luambaluis";
$banco_de_dados = "casamento";


 try 
 {
    $conn = mysqli_connect($host,$usuario,$senha,$banco_de_dados);
  
 } 
 catch (Exeption $ex)
 {
     echo $ex->getMessage();
    
 } 



?>