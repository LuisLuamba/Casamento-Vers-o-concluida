<?php

include "conexao.php";


session_start();


// $conn = mysqli_connect($host,$user,$password,$db);

if ($conn===false) 
{ 
    die("Conexao  erro");
    
}

if (isset($_POST["logar"]))
{
   $telefone=$_POST["telefone"];
   $password =$_POST["password"];


   $sql="SELECT * FROM  login  where telefone='".$telefone."'   AND   password='".$password."'  ";

   $resultado  = mysqli_query($conn,$sql);
   $row= mysqli_fetch_array($resultado);
   
   if ($row ["usertype"]=="user")  
   { 
        $_SESSION["username"] = $telefone;
       header("location: user.php"); 
   }
  
  elseif ($row ["usertype"]=="admin")  
   {
    $_SESSION["username"] = $telefone;
    
    header("location: admin.php"); 
   }
   else
   {
    echo "<script> alert('Número incorrecto ou convidado não cadastrado, por favor entre em contacto: 947 251 054');window.history.go(-1);</script>";
   }

}
?>




<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- Metas para telefone -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>Casamento</title>
    <!-- Metas para o site-->
    <meta name="keywords" content="">
    <meta name="description" content="Este é um site sobre convite digital">
    <meta name="author" content="Luís Luamba">
    <!-- Links  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <!-- Para funcionar em outros navegadores -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->


</head>
<body>
      
<!-- incluindo o cabecalho -->
<?php
include "assets/layout/cabecalho.php";
?>

<div class="">
   <span class="telalogin-texto"> <h3>FORMULÁRIO DE LOGIN  E DE CADASTRO</h3></span>
   <hr>
   <div class="ttt">
   <div class="container">
     <div class="row">
         <div class="col-4   text-center div-form">
                <!-- Primeiro Card -->
               <h5> FORMULÁRIO DO LOGIN </h5>
               <hr>
            <!-- Formulário 1 -->
               <form action="" method="post" >
               
               <input class="login" class="form-control" type="text" name="telefone" id="numero" placeholder="Insira o seu número de telefone" required="required">

               
               <input class="login" type="password" name="password" id="senhaa" placeholder="Repita número de telefone" required="required">
            
               <input class="login" type="submit" value="Entrar" name="logar">
               
               </form> 
               
         </div>
         
         </div>
         </div>
    </div>
</div>







        





<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
