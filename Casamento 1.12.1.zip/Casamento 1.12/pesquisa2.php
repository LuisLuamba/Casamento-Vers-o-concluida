<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- Metas para telefone -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>Casamento</title>
    <!-- Metas para o site-->
    <meta name="keywords" content="">
    <meta name="description" content="Este é um site sobre convite digital">
    <meta name="author" content="Luís Luamba">
    <!-- Links  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <!-- Para funcionar em outros navegadores -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->


</head>
<body>

<br>
<br>

<div class="container contorno">
    <div class="row">
        <!-- Primeiro Card -->
<h5 class="text-center p-3 bg-dark text-white" >CADASTRAR  E PESQUISAR O CONVIDADO</h5>
            
 <!-- conteudo principal do administrador -->
 
<div class="col-6  card-administrador-1">
                <!-- Primeiro Card -->
               <h5 class="text-center p-2 text-info bg-dark">CADASTRE AQUI!</h5>
               <hr>
               
               <form action="cadastrar_convidado.php" method="post">
                    <span class="telalogin-texto"> Nome do usuário</span>  <br>
                    <input class="cad-login"  type="text" name="username" autocomplete="on" required="required" placeholder="Insirá o nome do convidado"> <br> <br>
                    <span  class="telalogin-texto"> Numero telefone</span> <br>
                    <input type="text" class="cad-login" name="password" max="10" required="required" placeholder="Insirá o numero do celular"> <br> <br>
                    <!-- secion para tipo de usuario -->
                    <span class="telalogin-texto"> Defina a categoria do usuario</span> <br>
                   
                    <select name="tipousuario"  required="required">
                        <option value="">==Nivel do Usuário==</option>
                        <option value="admin"> admin</option>
                        <option value="user">user</option>
                        
                    </select> 
                
                
        <!-- fim secion para tipo de usuario --> 

        <!-- secion categori -->
                    <select name="categoriafamilia" id=""  required="required">
                        <option value=""> ==Grau Familiar ==</option>
                        <option value="Irmao (a) do Noivo"> Irmão (a) do Noivo </option>
                        <option value="Primo (a) do Noivo"> Primo (a) do Noivo </option>
                        <option value="Tio (a) doNoivo"> Tio (a) do Noivo </option>
                        <option value="Sobrinho (a) do Noivo"> Sobrinho (a) do Noivo </option>
                        <option value="Amigo (a) do (a)Noivo"> Amigo (a) do Noivo </option>
                        <option value="Colega do Noivo"> Colega do Noivo </option>
                                <!--  -->
                         
                        <option value="Irmao (a) da Noiva"> Irmão (a) da Noiva </option>
                        <option value="Primo (a) da Noiva"> Primo (a) da Noiva </option>
                        <option value="Tio (a) da  Noiva"> Tio (a) da Noiva </option>
                        <option value="Sobrinho (a) da Noiva"> Sobrinho (a) da Noiva </option>
                        <option value="Amigo (a) da Noiva"> Amigo (a) da Noiva </option>
                        <option value="Colega da Noiva"> Colega da Noiva </option>
                                     <!--  -->

                        <option value="Vizinhos"> Vizinhos  </option>
                        <option value="Igreja"> Igreja </option>
                           
                        
                    </select>
                    <br> <br>
                    <span class="telalogin-texto">Mesa</span>   <br>               
                  <input class="cad-login" required="required"  type="number" max="10"  min="1"  name="mesa" id="" placeholder="Insirá o nº da mesa do convidado"> <br> <br>
                  <span class="telalogin-texto">Repita o numero de celular</span>    <br>
                  <input class="cad-login"   type="text" name="telefone" required="required" max="10" placeholder="Insirá o numero do celular" MAX="9"> <br>
                 <input type="submit" value="Cadastrar" name="cadastrar-convidados" class="botao-cadastrar">
               
                </form>

         
         
                
    
                
                             
</div>

<div class="col-6   card-administrador-1">
                <!-- Primeiro Card -->
        <h5 class="text-center p-2 text-info bg-dark">PESQUISE AQUI</h5>
    <div class="container" >
        <div class="table-responsive">
<!-- campo de pesdquisa -->

<?php

include "conexao.php";
if(isset($_POST['search']))
{
    $searchkey = $_POST['search'];
    $sql = "SELECT * FROM login WHERE  usermane LIKE '%$searchkey%'";
}
else
{
    $sql = "SELECT * FROM login";
    $searchkey = "";
echo"NENUM DADO ENCONTRADO";
}


$resultado = mysqli_query ($conn, $sql);
?>

<form action="" method="POST"> 
     <input type="text"  name="search" id="pesquisador" value="<?php echo $searchkey; ?>">
    <!-- <button class="btn btn-info">Search</button> -->
    
</form>

<table class="table table-striped table-hover table-bordered table-dark  ">
    <tr class="bg-dark text-white text-center"> 

                    <th> ID</th>
                    <th> NOME</th>                
                    <th> MESA</th>
                    <th> CELULAR</th>                 
                    <th> ENTRAR</th>
                    <th> FALTOSO</th>
                    
                    </tr >   
                    <?php  while ($row  = mysqli_fetch_object($resultado)) { ?>  
       
                 
                    
                    <tr class="text-center">

                    <td><?php echo $row->id?></td>
                    <td><?php echo $row->usermane?></td>                                  
                    <td><?php echo $row->mesa?></td>
                    <td><?php echo $row->telefone?> </td>
                   
                    <!-- Botão faltoso  -->
                    
                    </tr >
                    <?php } ?>
                    
</table>



















         </div>
         </div>
         </div>
</div>
</div>