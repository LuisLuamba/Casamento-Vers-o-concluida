<?php
?>
 
 
 <script> 
       var msg = confirm(' Tem certeza que Deseja Apagar?');
       if(msg==false)
       {   
             
       
       alert(' Nao Apagado');window.history.go(-1);
        // Incluindo o Php para fazer a conexão
        
        
       }
       else
       {
              alert(' Apago com sucesso');window.history.go(-1);
       
             include 'conexao.php';
             $id = $_GET['id'];  
             $query = mysqli_query($conn, "DELETE FROM login WHERE id=$id");
                                    
       
       }
    
</script>
    
    
        

