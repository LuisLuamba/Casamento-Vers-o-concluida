 
<?php

session_start();
if (!isset($_SESSION["username"]))
{
    header("location:tela_login.php");
    
}
session_destroy();
?>

<h1>USER</h1><?php  echo  $_SESSION["username"]   ?>
<a href="Logout.php">Logout</a>