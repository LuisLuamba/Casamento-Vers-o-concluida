<!-- Diizeres do admiistrador -->

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- Metas para telefone -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>Casamento</title>
    <!-- Metas para o site-->
    <meta name="keywords" content="">
    <meta name="description" content="Este é um site sobre convite digital">
    <meta name="author" content="Luís Luamba">
    <!-- Links  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <!-- Para funcionar em outros navegadores -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->



<!-- Incluindo o Cabecalho -->
    <!--
        include "assets/layout/cabecalho.php";
    ?> -->
<!--Fim  Incluindo o Cabecalho -->


<div class="div-sair-do-sistema" style="margin:3px 0px 0px 0px;">    
        
        <div class="div-link-sair">
           <a href="Logout.php" >Sair do Sistema</a>
        </div>
     
        <div class="div-usuario-logado">
        <!--  echo "Seja Benvindo : ".$_SESSION["username"]  ?>  -->
        </div>

    </div>
    
<div class="container  col-lg-12">
     <div class="row">
    
         <div class="col-12 card-administrador p-3 ">
                <!-- Primeiro Card -->
               <h5 class="text-center p-3 bg-info text-white" >LISTA DOS CONVIDADOS</h5>
                <div class="container" >
                    <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered table-dark  ">
                    <tr class="bg-dark text-white text-center"> 

                    <th> ID</th>
                    <th> NOME</th>
                    <th> SENHA</th>
                    <th> NIVEL</th>
                    <th> CATEGORIA</th>
                    <th> MESA</th>
                    <th> CELULAR</th>
                    <th> DATA_CADASTRO</th>
                    <th> APAGAR</th>
                    <th> UPDATE</th>
                    <th> PDF</th>
                    
                    </tr >   
                    <?php
                    // Criando a Limitação de Exibição dos resultados
                    include "conexao.php"; 
                    $limitacao =5;
                    if(isset($_GET['page']))
                    {
                        $page = $_GET['page'];
                    }
                    else
                    {
                        $page =1;
                    }
                    $start_from = ($page - 1) * $limitacao;
                    $contador = mysqli_query($conn, "SELECT count(*) AS total_data FROM login");
                    //   $res =mysqli_query($conn,$query);
                    $row = mysqli_fetch_array($contador); 
                    $total_data = $row ['total_data'];
                    $total_page = ceil($total_data/$limitacao);  
                    if ($page >= $total_page)
                    {
                        $next=$total_page;
                    }
                    else
                    {
                        $next = $page + 1;
                    }
                    if ($page<=1)
                    {
                        $previous =1;
                    } 
                    else 
                    {
                       $previous = $page - 1;
                    }
                    


                    // Incluindo a conexao
                  
                    //  Solicitando a consulta  
                    $query = mysqli_query($conn, "SELECT * FROM login  LIMIT $start_from, $limitacao");
                     // Exibindo os resulados  
                    while($res= mysqli_fetch_array($query))
                    {

                    
                   ?>  

                    <tr class="text-center">

                    <td> <?php  echo $res['id']; ?> </td>
                    <td> <?php  echo $res['usermane']; ?> </td>
                    <td> <?php  echo $res['password']; ?> </td>
                    <td> <?php  echo $res['usertype']; ?></td>
                    <td> <?php  echo $res['categoria']; ?></td>
                    <td> <?php  echo $res['mesa']; ?></td>
                    <td> <?php  echo $res['telefone']; ?></td>
                    <td> <?php  echo $res['data_cadastro'];?> </td>
                    <!-- Botão apagar  -->
                    <td> 
                    
                    <button class="btn-danger btn "> 
                    <a href="delete.php?id=<?php echo $res['id'];?>" class="text-white" > Apagar </a>
                     </button> 
                    </td>
                    <!--Fim  Botão apagar  -->
                    
                     <!-- Botão Actualizar -->
                    
                     <td>
                    <button class="btn-info btn "> 
                    <a href="atualizar.php?id=<?php echo $res['id'];?>" class="text-white"> Update</a> 
                    </button> 
                    </td>

                    <td>
                    <button class="btn-dark btn "> 
                    <a href="convite_digital_luis_luamba.php?id=<?php echo $res['id'];?> " class="text-white"   target="_blanck"> PDF</a> 
                    </button> 
                    </td>

  
                    </tr >

                    <?php
                    }
                    
                    ?>
                   <hr>
                   
      </table>
     <nav aria-label="Page navigation example">
       
       <ul class="pagination">
       <li class="page-item"><a class="page-link" href="visualizar.php?page=<?php echo $previous; ?> ">Voltar</a></li>  
       <?php
       for ($i=1; $i <= $total_page; $i++) { ?>
             
          <li class="page-item"><a class="page-link" href="visualizar.php?page=<?php echo $i; ?> "><?php echo $i; ?> </a></li>
       <?php }
          
       ?>  
       <li class="page-item"><a class="page-link" href="visualizar.php?page=<?php echo $next; ?> ">Avançar</a></li>     
        </ul>
       
  </nav>
 
      <!-- Paginação  -->
   



      </div>                          
</div>
</div>
</div>   
</div>

<!-- Incluindo menu inserir -->


<!-- Fim Inserir -->
<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>

