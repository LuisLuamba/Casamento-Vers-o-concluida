<!-- Cadastrar convidado -->
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">

<?php
include "conexao.php";


if (isset($_POST["cadastrar-convidados"]))
{
    $username = $_POST["username"];
    $passord = $_POST["password"];
    $usertype= $_POST["tipousuario"];
    $categoriafamilia = $_POST["categoriafamilia"];
    $mesa = $_POST["mesa"];
    $telefone = $_POST["telefone"];

  
}






// $comando="SELECT * FROM id FROM login WHERE password ='$passord' "
$query = mysqli_query($conn, "SELECT * FROM login  WHERE telefone='".$telefone."'");
//--------------------------------------------------------//
// verificando se os numeros são iguais
if ($passord != $telefone)
{
    echo "<script> alert('Numeros de telefones diferentes! os numeros devem ser iguais');window.history.go(-1);</script>";
}
//--------------------------------------------------------//
else
{
// Verificando se jjá existe um usuári cadastrado com o mesmo nome 
//--------------------------------------------------------//
if(mysqli_num_rows($query) > 0)
{
    echo "<script> alert('CONVIDADO JA CADASTRADO -> POR FAVOR -> CADASTRE OUTRO CONVIDADO');window.history.go(-1);</script>";
}
//--------------------------------------------------------//

        // INSIRINDO OS DADOS NA TABELA 
//--------------------------------------------------------//
else
{
   $query = mysqli_query($conn, "INSERT INTO login (usermane,password,usertype,categoria,mesa,telefone) VALUES ('$username','$passord','$usertype', '$categoriafamilia','$mesa','$telefone') ");
   echo "<script> alert('CONVIDADO CADASTRADO COM SUCESSO');window.history.go(-1);</script>";
}

}


?>
