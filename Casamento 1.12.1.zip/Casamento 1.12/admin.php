<?php
include "conexao.php";                
 $query = mysqli_query($conn, "SELECT * FROM login");
?>   

<!-- Deslognado apos -->
<meta http-equiv="refresh" content="1800; url=tela_login.php">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<?php
session_start();
if (!isset($_SESSION["username"]))
{
    //  header("location:tela_login.php");
    
}
session_destroy();
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <!-- Metas para telefone -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>Casamento</title>
    <!-- Metas para o site-->
    <meta name="keywords" content="">
    <meta name="description" content="Este é um site sobre convite digital">
    <meta name="author" content="Luís Luamba">
    <!-- Links  -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <!-- Para funcionar em outros navegadores -->

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->


</head>
<body>






<!-- incluindo o cabecalho -->
<?php
include "assets/layout/cabecalho.php";
?> 
<!--Fim incluindo o cabecalho -->




<br>

<!-- MENU -->
<!-- Aplicando o Container -->
<fieldset>
<div class="container">
    <div class="row">
        <div class="col-4 text-center card-admin">
         <!-- Primeiro Card do menu Cadastro -->
            <h5 style="color: #990033;">CADASTRAR</h5>
               <hr>
               <p class="card-text " >Clicando aqui poderás, cadastrar  convidados para sua actividade</p>
                <img src="assets/img/icones/pessoas.png" alt="" class="slider" height="24%">
                <a href="inserir.php" class="btn btn-link-cards-admin">Clique para cadastrar</a>
                
                             
         </div>
            
            
        <!-- Fim Primeiro Card do menu Cadastro -->
        

        

      <!-- Card para Visualisar -->
       
 <!-- Card para Visualisar -->
 <div class="col-4   text-center card-admin">
                <!-- Primeiro Card -->
               <h5 style="color: #990033;">VISUALIZAR</h5>
               <hr>
               <p class="card-text">Clicando aqui poderás visualizar todos os convidados,podendo ainda Actualizar, Apagar os seus dados</p>
                <img src="assets/img/icones/ver.png" alt="" class="slider" height="20%">
                <a href="visualizar.php" class="btn btn-link-cards-admin">Clique para visualizar</a>
        
         </div>
 


         <!-- Card para Visualisar -->
        
         <div class="col-4   text-center card-admin">
                <!-- Primeiro Card -->
               <h5 style="color: #990033;">CONSULTAR</h5>
               <hr>
               <p class="card-text">Clicando aqui poderás consultar e imprimir conites de convidados</p>
            <img src="assets/img/icones/imprimir.png" alt="" class="slider" height="24%">
            <a href="pesquisar_convidado.php" class="btn btn-link-cards-admin">Clique para consultar</a>
           
         </div>



         
         <!-- Card para Visualisar -->

         

        </div>
    </div>
</div>
<hr style="color: black; Padding:1%;"> 
<!--Fim  Aplicando o Container -->






<!-- FIM MENU -->





<!-- Incluindo O Visualiazador -->
<!-- 
include "visualizar.php";
?> -->

<!-- Fm Incluindo O Visualiazador -->


<!-- INSERIR  -->
<!-- 
include "assets/operacoes/inserir.php";
?> -->



        


    
<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
