-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 05-Mar-2021 às 05:06
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `casamento`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usermane` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'user',
  `categoria` varchar(20) NOT NULL,
  `mesa` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`id`, `usermane`, `password`, `usertype`, `categoria`, `mesa`, `telefone`, `data_cadastro`) VALUES
(1, 'admin', '1234', 'admin', '', '', '947251054', '2021-03-03 20:42:45'),
(2, 'user', '1234', 'user', '', '', '', '2021-03-03 20:42:45'),
(3, 'João Marino Luamba', '12345', 'admin', 'Noivo do noivo', '5', '12345', '2021-03-03 21:36:30'),
(4, 'João Marino Luamba', '1', 'user', '', '', '1', '2021-03-03 22:21:34'),
(5, '', '2', 'admin', '', '', '2', '2021-03-03 22:22:10'),
(6, 'Luis Luamba', '947251054', 'user', '', '', '947251054', '2021-03-04 22:48:26'),
(7, 'Miguel SimÃ£o', '924409498', 'user', '', '', '947251054', '2021-03-04 22:49:43'),
(8, 'luis ', '947251054', 'user', '', '', 'u', '2021-03-04 22:51:27'),
(9, 'luis ', '947251054', 'user', '', '', '947251054', '2021-03-04 23:10:19'),
(10, 'luis ', '947251054', 'user', '', '', '947251054', '2021-03-04 23:10:31'),
(11, 'luis ', '947251054', 'user', '', '', '947251054', '2021-03-04 23:12:06'),
(12, 'luis ', '947251054', 'user', '', '', '947251054', '2021-03-04 23:12:10'),
(13, 'luis ', '924409498', 'user', '', '', '222', '2021-03-04 21:27:01'),
(14, '1', '11', 'user', '', '', '94725105', '2021-03-04 21:52:24'),
(15, '1', '11', 'user', '', '', '947251053', '2021-03-04 21:53:10'),
(16, '1', '1', 'user', '', '', '9472510', '2021-03-04 22:03:35'),
(17, 'm', 'm', 'admin', '', '', 'm', '2021-03-04 23:56:46'),
(18, 'cccc', 'ccccc', 'admin', '', '', '922222222222', '2021-03-04 23:57:43'),
(19, '7', '7', 'admin', 'Igreja', '', '7', '2021-03-05 00:02:02'),
(20, '7', '7', 'admin', 'catego', '', '9', '2021-03-05 00:02:42'),
(21, '7', '7', 'admin', 'catego', '', '10', '2021-03-05 00:03:39'),
(22, '11', '11', 'admin', 'IrmÃ£o (a) do Noivo', '', '11', '2021-03-05 00:04:09'),
(23, 'Henriqueta Julio da Silva', '95478446', 'admin', 'Irmao (a) da Noiva', '', '2569', '2021-03-05 00:06:41'),
(24, 'JosÃ© Gonga', '923', '', '', '2', '923', '2021-03-05 00:15:57'),
(26, 'Luis Luamba', '23', 'admin', 'Irmao (a) do Noivo', '-5', '45', '2021-03-05 00:24:16'),
(27, 'Luis Luamba', '23', 'admin', 'Irmao (a) do Noivo', '0', '5', '2021-03-05 00:25:10'),
(28, 'Luis Luamba', '23', 'admin', 'Irmao (a) do Noivo', '1', '6', '2021-03-05 00:25:39'),
(29, '3', '6', 'user', 'Sobrinho (a) do Noiv', '5', '96', '2021-03-05 00:26:27'),
(30, '1', '947251054', 'admin', 'Tio (a) doNoivo', '1', '94725108521', '2021-03-05 00:29:49'),
(31, '0', '0', 'user', 'Irmao (a) do Noivo', '1', '00', '2021-03-05 00:34:38'),
(32, 'W', 'W', 'admin', 'Irmao (a) do Noivo', '2', '947251054', '2021-03-05 00:48:44'),
(33, '555', '555', 'admin', 'Colega da Noiva', '5', '5555555', '2021-03-05 00:49:06'),
(34, '555', '555', 'admin', 'Colega da Noiva', '5', '5555555', '2021-03-05 00:49:11'),
(35, '55555', '555555', 'admin', 'Vizinhos', '2', '5555555', '2021-03-05 00:50:21'),
(36, '111', '1111', 'admin', 'Vizinhos', '1', '1111', '2021-03-05 00:58:36'),
(37, '111111111111111111', '1111111111111111111111111', 'admin', 'Igreja', '10', '11111111111111111111', '2021-03-05 01:01:30'),
(38, '111111111111111111', '1111111111111111111111111', 'admin', 'Igreja', '10', '11111111111111111111', '2021-03-05 01:01:35'),
(39, '111111111111111111', '1111111111111111111111111', 'admin', 'Igreja', '10', '11111111111111111111', '2021-03-05 01:01:38'),
(40, '111111111111111111', '1111111111111111111111111', 'admin', 'Igreja', '10', '11111111111111111111', '2021-03-05 01:01:38'),
(41, '1', '1', 'user', '', '', '1111', '2021-03-05 01:02:48'),
(42, '', '', 'user', '', '', '', '2021-03-05 01:03:08'),
(43, 'yyy', 'yy', 'user', 'yyyy', 'yyy', 'yyyy', '2021-03-05 01:03:47'),
(44, '111', '1111', 'user', '111', '111', '1111', '2021-03-05 01:04:14'),
(45, '11111', '1111', 'user', '111', '1111', '11111', '2021-03-05 01:04:49'),
(46, '111', '1111', 'admin', 'Irmao (a) do Noivo', '1', '111', '2021-03-05 01:05:47');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
