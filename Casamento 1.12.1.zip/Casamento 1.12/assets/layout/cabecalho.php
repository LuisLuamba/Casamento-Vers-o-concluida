<!-- Div princippal  -->

<div class="container-fluid">
    <div class="row">
         <div class="col-md-12  cor ">
          <?php
            include "assets/layout/navegacao.php"; 
          ?>
        </div>
      </div>

</div>