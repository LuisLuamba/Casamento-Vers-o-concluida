<div class="container-fluid  ">
    <div class="row ">
        <div class="col-12 cor1 p-2 text-center fixed-botto">
                <!-- Usando o php para o copytrite -->
                
                <?php
                 echo'<span class="cor-texto-letra-menu-nav-bar"> <h5>  &copy  Copyright '. date("d-m-Y").'  Todos os Direitos Reservados </h5> </span>';
                 echo' <span class="cor-texto-letra-menu-nav-bar"> <h5>    Desenvolvido por Luís Luamba </h5>  </span>';
                ?>
                            <!-- Incluindo os icones -->
              <a href=""> <img src="assets/img/icones/facebook.png" alt=""></a>
              <a href="mailto:luisfranciscoluamba@gmail.com"> <img src="assets/img/icones/email.png" alt="">  </a>
                
               
        </div>

    </div>

</div>