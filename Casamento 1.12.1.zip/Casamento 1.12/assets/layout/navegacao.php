<!-- Redifinindo a div do logotipo  -->
<div class=" div-logotipo">
    <a href="index.php"><img src="assets/img/logotipo.png" alt="" class="logotipo img-responsive" >  </a>   
</div>

<!-- Redifinindo a div do da navegação -->

<div class="menu-responsivo">

<nav class="navbar navbar-expand-lg navbar-light  ">
   <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarText">
  <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"> <span class="cor-texto-letra-menu-nav-bar"> Ínicio</span>  </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="localizacao.php"> <span class="cor-texto-letra-menu-nav-bar">Localização</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tela_login.php"><span class="cor-texto-letra-menu-nav-bar">Login</span></a>
      </li>
    </ul>
  </div>
  </nav>

</div>
