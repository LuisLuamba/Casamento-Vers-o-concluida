<br>
<br>
<section>
<!-- Informção -->
<span class="formatacao-informação"> <u><h1>Informção</h1></u></span> 
 <!-- Container com as informações Necessarias e Justificações -->
<div class="container">
      <div class="row">
        <div class="col-3 cor-conteudo-informacao ">
         <span class="texto-informacao"> É com grande Algria e uma enorme Felicidades que  Luís Luamba junto a sua Noiva   Agradecem por acessar este site!</span> <br> <br>
          O mundo está cada vez mais digital, em que actualmente quase tudo, funciona
          a base de apenas um clique, facilitando assim a vida do ser humano, em tarefas
          que exutando de uma forma tradicional levaria anos, meses, dias e horas, para atingir 
          um determinado objectivo. 
          Surge a tecnologia, com o objectivo de automatizar as tarefas. <br> <br>

          <span class="texto-informacao"> Daí decidimos em criar um sistema, com todas as informações necessárias! 
          Afim de facilitar os nossos convidados.</span>


        </div>

      </div>

  </div>
 
  </section>
  <!-- Fim  Container com as informações Necessarias e Justificações -->
 
  <!-- Adicionand os cardes para as fotos -->
  <div class="container">
     <div class="row">
         <div class="col-4   text-center card1">
                <!-- Primeiro Card -->
               <h5>O Casameno é umas dadiva de Deus!</h5>
               <hr>
               <img src="assets/img/slider/concluida.png" alt="" class="slider">
                <h3>
                    O NOIVO
                </h3>
               <hr>
         </div>




         <div class="col-4   text-center card1">
                <!-- Primeiro Card -->
               <h5>Não é bom que o homem esteje só!</h5>
               <hr>
               <img src="assets/img/slider/nos.jpg" alt="" class="slider"   height="340px" >
                <h3>
                    Nós 
                </h3>
               <hr>
         </div>




         <div class="col-4   text-center card1">
                <!-- Primeiro Card -->
               <h5>Casar é um privilégio!</h5>
               <hr>
               <img src="assets/img/slider/noiva.jpg" alt="" class="slider" height="340px">
                <h3>
                    O NOIVA
                </h3>
               <hr>
         </div>
         

     </div>

 </div>


